# Streams vs. Screens (CSCE 5320 project)

Spotify streams vs. YouTube views, and how far audio features explain popularity.

## Folder layout

```
streams-vs-screens/
  app.py             Streamlit dashboard (interactive visualizations)
  analysis.py        Runs the full analysis, writes figures + summary.txt to results/
  requirements.txt   Python dependencies
  data/              Put Spotify_Youtube.csv here
  results/           Output of analysis.py (created automatically)
  .vscode/           Run/debug configurations
```

## Setup (VS Code terminal, from this folder)

macOS / Linux:
```
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Windows (PowerShell):
```
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

Then in VS Code: Ctrl/Cmd+Shift+P, "Python: Select Interpreter", choose `.venv`.

## Data

Download `Spotify_Youtube.csv` from
https://www.kaggle.com/datasets/salvatorerastelli/spotify-and-youtube
and place it in `data/`. The file should hold about 20,700 rows. If the scripts
warn about fewer than about 19,000 rows, the file is damaged; re-download it.

## Run

Analysis (prints every number for the report, saves figures to `results/`):
```
python analysis.py
```

Dashboard:
```
streamlit run app.py
```

Or use the Run and Debug panel (F5) and pick a configuration.

## Outputs in results/

- `summary.txt`: all numbers needed for the progress report
- `fig1_streams_vs_views.png/.html`, `fig2_feature_correlations.png/.html`,
  `fig3_group_comparison.png`, `fig4_rq4_importances.png`, `dashboard.html`
- `rq1_correlations.csv`, `rq2_feature_correlations.csv`,
  `rq3_group_feature_means.csv`, `rq4_model_results.csv`
